@extends('layouts.admin')

@section('title')
Edit Banner
@endsection

@section('content')

<div class="content-header row">

    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-left mb-0">Edit Banner</h2>
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route('admin.banners.index') }}">Manage Advertisement</a>
                        </li>
                        <li class="breadcrumb-item active">Edit Banner
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
        <div class="form-group breadcrum-right">
            <div class="dropdown">
                <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle waves-effect waves-light"
                    type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="feather icon-settings"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="content-body">

    <section>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Edit Banner</h4>
                    </div>
                    <div class="card-content">

                        <div class="card-body">

                            <form method="post" action="{{ route('admin.banners.update',$banner->id) }}"
                                id="banner_form" enctype="multipart/form-data">

                                @csrf

                                @method('PUT')

                                <div class="row">

                                    <div class="col-xl-6 col-md-6 col-12 mb-1">
                                        <fieldset class="form-group">
                                            <label for="name" class="mb-1">Select Offer</label>
                                            <select class="select2 form-control select2-hidden-accessible"
                                                name="offer_id">
                                                <option value="">Select Offer</option>
                                                @if(count($offers)>0)
                                                @foreach ($offers as $offer)
                                                <option value="{{ $offer->id }}" {{ (old('offer_id')||$banner->offer_id)==$offer->id ?
                                                    'selected' : '' }} >{{ $offer->offer_name }}</option>
                                                @endforeach
                                                @endif
                                            </select>
                                        </fieldset>
                                    </div>                                    

                                    <div class="col-xl-6 col-md-6 col-12 mb-1">
                                        <fieldset class="form-group">
                                            <label for="basicInputFile" class="mb-1">Banner Image</label>
                                            <div class="custom-file">
                                                <input type="file" name="banner_image"
                                                    class="custom-file-input @error('banner_image') is-invalid @enderror"
                                                    id="inputGroupFile01" accept="image/*">
                                                <label class="custom-file-label" for="inputGroupFile01">Choose
                                                    file</label>
                                            </div>
                                        </fieldset>
                                    </div>

                                    <div class="col-xl-6 col-md-6 col-12 mb-1">
                                        <fieldset class="form-group">
                                            <label class="mb-1 d-block">Banner Status</label>
                                            <div class="custom-control custom-switch custom-control-inline">
                                                <input type="checkbox" name="banner_status" class="custom-control-input"
                                                    value="1" id="customSwitch1" {{ old('banner_status') ||
                                                    $banner->banner_status ? 'checked' : '' }}>
                                                <label class="custom-control-label" for="customSwitch1">
                                                </label>
                                                <span class="switch-label"></span>
                                            </div>
                                        </fieldset>
                                    </div>

                                    <div class="col-xl-6 col-md-6 col-12 mb-1">
                                        <fieldset class="form-group">
                                            <label for="name" class="mb-1">Banner Location</label>
                                            <select class="form-control" name="banner_location">
                                                <option value="1" <?= ($banner->banner_location==1) ? 'selected' : '';?> >Header</option>
                                                <option value="2" <?= ($banner->banner_location==2) ? 'selected' : '';?>>Footer</option>                                               
                                            </select>
                                        </fieldset>
                                    </div>   

                                    <div class="col-xl-6 col-md-6 col-12 mb-1">
                                        @if($banner->banner_image!='')
                                        <img src="{{ asset('uploads/banners/'.$banner->banner_image) }}"
                                            class="img-thumbnail" height="100" width="100" />
                                        @endif
                                    </div>

                                </div>

                                <button type="submit"
                                    class="btn btn-primary mr-sm-1 mb-1 mb-sm-0 waves-effect waves-light">
                                    Submit
                                </button>

                                <form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</div>

@endsection

@section('footer')

<script>
    $(document).ready(function(){
        $("#banner_form").validate({
            debug: true,
            errorClass: 'error',
            validClass: 'success',
            errorElement: 'span',
            highlight: function(element, errorClass, validClass) {
                $(element).addClass("is-invalid");
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).parents(".error").removeClass("error");
                $(element).removeClass("is-invalid");
            },
            rules:{                
                offer_id:{
                    required:true,
                },
               
                // banner_image:{
                //     required:true,
                // },
            },

            messages: {
                offer_id: {
                    required: "Select Offer",
                },
                
                // banner_image: {
                //     required: "Offer Image Required",
                // },
            },
            submitHandler: function(form) {
                form.submit();
            }   
        });
    });
</script>
@endsection